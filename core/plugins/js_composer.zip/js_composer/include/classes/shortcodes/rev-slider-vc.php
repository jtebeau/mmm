<?php
class WPBakeryShortCode_Rev_Slider_Vc extends WPBakeryShortCode {
}